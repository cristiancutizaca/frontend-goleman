"use client";

import React, { useState, useEffect } from "react";
import { Tabs, Tab, Card, CardBody } from "@nextui-org/react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";

import Admipros from "./guiaAdmi";
import Precios from "./precios";
import Formulario from "./AdmissionForm";
import Documentos from "./documentos.jsx";

const Graduate = () => {
  return (
    <section id="/diplomados" className="bg-white text-[#124559]">
      <div className="p-5 flex flex-col">
        {/* Proceso de Admisión Colegio Goleman */}
        <motion.section
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center py-16 px-6"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-[#0B8457] mb-12">
            Proceso de Admisión
          </h2>

          <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto">
            {[
              {
                number: "1",
                title: "Bienvenida y presentación institucional",
                text:
                  "Participa en nuestras charlas mensuales para conocer al Colegio Intercultural Daniel Goleman. Llenando el formulario de contacto te agendaremos una cita virtual con nuestro equipo pedagógico y directivo."
              },
              {
                number: "2",
                title: "Envío de formulario de admisión",
                text:
                  "Luego de la presentación, te haremos llegar el formulario oficial de postulación para ser completado en los plazos indicados."
              },
              {
                number: "3",
                title: "Entrevista personalizada",
                text:
                  "Nuestro equipo de admisión se comunicará para coordinar una entrevista con la familia postulante."
              },
              {
                number: "4",
                title: "Resultados",
                text:
                  "Los resultados serán comunicados vía correo electrónico en un plazo de 10 días posteriores a la entrevista."
              },
              {
                number: "5",
                title: "Pago de matrícula",
                text:
                  "Las familias admitidas deberán abonar la cuota correspondiente en un plazo de 7 días para confirmar su vacante."
              },
              {
                number: "6",
                title: "Inicio del proceso de acogida",
                text:
                  "Desde noviembre, iniciamos el acompañamiento con las familias admitidas para su integración a la comunidad Goleman."
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                whileHover={{ scale: 1.02 }}
                className="text-left"
              >
                <div className="text-[#0B8457] font-bold text-xl flex items-center gap-4 mb-2">
                  <div className="w-10 h-10 border-2 border-[#0B8457] rounded-full flex items-center justify-center text-lg">
                    {item.number}
                  </div>
                  <span>{item.title}</span>
                </div>
                <p className="text-sm leading-relaxed text-gray-700">
                  {item.text}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Secciones restantes */}
        <div className="mb-20 lg:mb-10">
          <Admipros />
        </div>
        <div className="mb-20 lg:mb-10">
          <Precios />
        </div>
        <div className="mb-20 lg:mb-10">
          <Documentos />
        </div>
        <div className="mb-20 lg:mb-10">
          <Formulario />
        </div>
      </div>
    </section>
  );
};

export default Graduate;
